package com.csci572.adhocmessaging.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF03989E)
val BlueGray80 = Color(0xFF808080)
val Gray80 = Color(0xFFFCFCFC)

val DarkGray80 = Color(0xFF383838)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)